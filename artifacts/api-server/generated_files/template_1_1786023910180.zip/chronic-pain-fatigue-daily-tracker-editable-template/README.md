# Editable template package: Chronic Pain & Fatigue Daily Tracker

This package contains editable vector assets for Canva and Affinity.

## Files

- `cover/cover.svg` — editable full-wrap cover with back, spine, front, bleed, trim, safe-area, and barcode guides.
- `cover/cover.pdf` — vector PDF version of the cover.
- `interior/interior-template.svg` — reusable editable page templates stacked in one SVG artboard.
- `interior/interior-template.pdf` — vector PDF with one page per reusable template.
- `template.json` — dimensions, page count, palette, and export metadata.

Interior templates included: title, introduction, daily-tracker, weekly-review, habit-tracker, notes.

## Workflow

1. Import the SVG or PDF into Canva or Affinity.
2. Edit elements marked as editable and duplicate interior pages as needed.
3. Remove red guide lines, placeholder labels, and barcode placeholder before publishing.
4. Use the existing KDP-ready PDF generator for the final upload file when you do not need edits.

This export does not create native `.canva` or `.afdesign` files.
